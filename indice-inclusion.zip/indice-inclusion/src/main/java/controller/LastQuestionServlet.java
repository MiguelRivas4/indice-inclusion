package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.QuestionModel;

@WebServlet(name = "LastQuestionServlet", urlPatterns = "/LastQuestionServlet")
public class LastQuestionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        List<QuestionModel> questions = (List<QuestionModel>) session.getAttribute("pregAsignadas");

        int index = Integer.parseInt(request.getParameter("index"));

        if (index > 0 && index < questions.size()) {
            response.sendRedirect(request.getContextPath() + "/Mi_cuestionario.jsp?index=" + (index - 1));
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

}
