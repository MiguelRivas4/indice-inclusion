package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ConexionBD;
import model.QuestionModel;

@WebServlet(name = "CulturaInclusivaServlet", urlPatterns = "/CulturaInclusivaServlet")
public class CulturaInclusivaServlet extends HttpServlet {

    List<QuestionModel> questions;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Guarda la lista de preguntas que devuelve la funcion getQuestions
        questions = getQuestions();

        // Guarda la lista de preguntas en la sesión para usarla en el JSP
        request.getSession().setAttribute("preguntas", questions);

        //SE REDIRECCIONA A LA PAGINA PARA ADMINISTRAR PREGUNTAS DE "CULTURA INCLUSIVA"
        response.sendRedirect(request.getContextPath() + "/Cultura_inclusiva.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("accion");

        switch (action) {
            case "add":
                //CODIGO PARA AGREGAR PREGUNTA
                String dimension = request.getParameter("dimension");
                String ambito = request.getParameter("ambito");
                String enunciado = request.getParameter("enunciado");
                int id_tipo = Integer.parseInt(request.getParameter("id_tipo"));

                CreateQuestion(dimension, ambito, enunciado, id_tipo);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                questions = getQuestions();
                request.getSession().setAttribute("preguntas", questions);
                response.sendRedirect(request.getContextPath() + "/Cultura_inclusiva.jsp");
                break;

            case "edit":
                //FUNCIONALIDAD PARA ACTUALIZAR TUTORIAL
                //Se obtiene los valores de los campos 
                int id_questionE = Integer.parseInt(request.getParameter("id_questionE"));
                String dimensionE = request.getParameter("dimensionE");
                String ambitoE = request.getParameter("ambitoE");
                String enunciadoE = request.getParameter("enunciadoE");
                int id_tipoE = Integer.parseInt(request.getParameter("id_tipoE"));

                updateQuestion(id_questionE, dimensionE, ambitoE, enunciadoE, id_tipoE);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                questions = getQuestions();
                request.getSession().setAttribute("preguntas", questions);
                response.sendRedirect(request.getContextPath() + "/Cultura_inclusiva.jsp");
                break;

            case "delete":
                //FUNCIONALIDAD PARA ELIMINAR PREGUNTA
                int id_questionD = Integer.parseInt(request.getParameter("id_questionD"));

                deleteQuestion(id_questionD);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                questions = getQuestions();
                request.getSession().setAttribute("preguntas", questions);
                response.sendRedirect(request.getContextPath() + "/Cultura_inclusiva.jsp");
                break;
        }

    }

    //METODO PARA "CREAR" PREGUNTA
    private static boolean CreateQuestion(String dimension, String ambito, String enunciado, int id_tipo) {

        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO pregunta (dimension_pregunta, ambito_pregunta, enunciado_pregunta, id_tipo) VALUES (?, ?, ?, ?);";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, dimension);
            statement.setString(2, ambito);
            statement.setString(3, enunciado);
            statement.setInt(4, id_tipo);

            statement.executeUpdate();

            // Devolver true si se ejecuto correctamente
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return false;
        }
    }

    //METODO PARA "LEER" PREGUNTAS
    private static List<QuestionModel> getQuestions() {
        List<QuestionModel> questions = new ArrayList<>();
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT * FROM pregunta WHERE dimension_pregunta=? ORDER BY id_pregunta ASC";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, "Cultura inclusiva");

            resultSet = statement.executeQuery();

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                QuestionModel question = new QuestionModel();
                question.setQuestionId(resultSet.getInt("id_pregunta"));
                question.setDimension(resultSet.getString("dimension_pregunta"));
                question.setAmbit(resultSet.getString("ambito_pregunta"));
                question.setQuestionDesc(resultSet.getString("enunciado_pregunta"));
                question.setCodeRol(resultSet.getInt("id_tipo"));
                question.setCodRoleName(resultSet.getInt("id_tipo"));

                questions.add(question);
            }

            // Devolver la lista de tutoriales
            return questions;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA "ACTUALIZAR" PREGUNTA
    private static int updateQuestion(int id_questionE, String dimensionE, String ambitoE, String enunciadoE, int id_tipoE) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR TUTORIAL
            String sql = "UPDATE pregunta SET dimension_pregunta= ?, ambito_pregunta= ?, enunciado_pregunta= ?, id_tipo= ? WHERE id_pregunta = ? ";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, dimensionE);
            statement.setString(2, ambitoE);
            statement.setString(3, enunciadoE);
            statement.setInt(4, id_tipoE);
            statement.setInt(5, id_questionE);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }
    
    //METODO PARA "ELIMINAR" PREGUNTA
    private static int deleteQuestion(int id_questionD) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR MANUAL
            String sql = "DELETE FROM pregunta WHERE id_pregunta=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, id_questionD);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }
}
