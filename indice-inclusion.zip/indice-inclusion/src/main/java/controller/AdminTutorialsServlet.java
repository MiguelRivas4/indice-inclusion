package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ConexionBD;
import model.ManualModel;
import model.TutorialModel;

@WebServlet(name = "AdminTutorialsServlet", urlPatterns = "/AdminTutorialsServlet")
public class AdminTutorialsServlet extends HttpServlet {

    List<TutorialModel> tutoriales;
    List<ManualModel> manuales;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //CREA UN OBJETO PARA OBTENER LA SESION ACTUAL

        //Guarda la lista de tutoriales que devuelve la funcion getTutorials
        tutoriales = getTutorials();

        //Guarda la lista de manuales que devuelve la funcion getManuals
        manuales = getManuals();

        // Guarda la lista de tutoriales y manuales en la sesión para usarla en el JSP
        request.getSession().setAttribute("tutoriales", tutoriales);
        request.getSession().setAttribute("manuales", manuales);

        //SE REDIRECCIONA A LA PAGINA DE TUTORIALES Y MANUALES
        response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("accion");

        switch (action) {
            case "addT":
                //FUNCIONALIDAD PARA AGREGAR TUTORIAL
                //Se obtiene los valores de los campos 
                int forAdmin = Integer.parseInt(request.getParameter("para"));
                String tutorialName = request.getParameter("nombre");
                String tutorialLink = request.getParameter("enlace");

                CreateTutorial(forAdmin, tutorialName, tutorialLink);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                tutoriales = getTutorials();
                request.getSession().setAttribute("tutoriales", tutoriales);
                response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");
                break;

            case "editT":
                //FUNCIONALIDAD PARA ACTUALIZAR TUTORIAL
                //Se obtiene los valores de los campos 
                int editIdT = Integer.parseInt(request.getParameter("id_tutorial"));
                int newForAdmin = Integer.parseInt(request.getParameter("nuevoPara"));
                String newTutorialName = request.getParameter("nuevoNombre");
                String newTutorialLink = request.getParameter("nuevoEnlace");

                updateTutorial(editIdT, newForAdmin, newTutorialName, newTutorialLink);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                tutoriales = getTutorials();
                request.getSession().setAttribute("tutoriales", tutoriales);
                response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");
                break;

            case "deleteT":
                //FUNCIONALIDAD PARA ELIMINAR TUTORIAL
                int tutorial_idD = Integer.parseInt(request.getParameter("id_tutorialD"));

                deleteTutorials(tutorial_idD);

                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                tutoriales = getTutorials();
                request.getSession().setAttribute("tutoriales", tutoriales);
                response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");
                break;

            case "editM":
                //FUNCIONALIDAD PARA EDITAR MANUAL
                //Se obtiene los valores de los campos 
                int editIdM = Integer.parseInt(request.getParameter("id_manual"));
                String newManualName = request.getParameter("nuevoNombreM");
                String newManualLink = request.getParameter("nuevoEnlaceM");

                updateManual(editIdM, newManualName, newManualLink);
                
                //SE EXPORTAN LOS TUTORIALES Y SE RECARGA LA PAGINA
                manuales = getManuals();
                request.getSession().setAttribute("manuales", manuales);
                response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");
                break;

            case "deleteM":
                //FUNCIONALIDAD PARA ELIMINAR MANUAL
                int manual_id = Integer.parseInt(request.getParameter("id_manualD"));

                deleteManual(manual_id);

                //SE EXPORTAN LOS MANUALES Y SE RECARGA LA PAGINA
                manuales = getManuals();
                request.getSession().setAttribute("manuales", manuales);
                response.sendRedirect(request.getContextPath() + "/Administracion_tutoriales_y_manuales.jsp");
                break;
        }

    }

    //METODO PARA "CREAR" TUTORIAL
    private static boolean CreateTutorial(int admin_flag, String tutorial_name, String tutorial_link) {
        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO tutorial (para_admin, nombre_tutorial, enlace_tutorial) VALUES (?, ?, ?);";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, admin_flag);
            statement.setString(2, tutorial_name);
            statement.setString(3, tutorial_link);

            statement.executeUpdate();

            // Devolver true si se ejecuto correctamente
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return false;
        }
    }

    //METODO PARA "LEER" TUTORIALES
    private static List<TutorialModel> getTutorials() {
        List<TutorialModel> tutoriales = new ArrayList<>();
        ResultSet resultSet = null;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT * FROM tutorial ORDER BY id_tutorial ASC";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                TutorialModel tutorial = new TutorialModel();
                tutorial.setTutorialId(resultSet.getInt("id_tutorial"));
                tutorial.setAdminFlag(resultSet.getInt("para_admin"));
                tutorial.setAdminFlagName(resultSet.getInt("para_admin"));
                tutorial.setTutorialName(resultSet.getString("nombre_tutorial"));
                tutorial.setTutorialLink(resultSet.getString("enlace_tutorial"));

                tutoriales.add(tutorial);
            }

            // Devolver la lista de tutoriales
            return tutoriales;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA "ACTUALIZAR" TUTORIAL
    private static int updateTutorial(int tutorial_id, int forAdmin, String TutorialName, String TutorialLink) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR TUTORIAL
            String sql = "UPDATE tutorial SET para_admin= ?, nombre_tutorial= ?, enlace_tutorial = ? WHERE id_tutorial = ? ";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, forAdmin);
            statement.setString(2, TutorialName);
            statement.setString(3, TutorialLink);
            statement.setInt(4, tutorial_id);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }

    //METODO PARA "ELIMINAR" TUTORIAL
    private static int deleteTutorials(int tutorial_id) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR TUTORIAL
            String sql = "DELETE FROM tutorial WHERE id_tutorial=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, tutorial_id);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }

    //METODO PARA "LEER" MANUALES
    private static List<ManualModel> getManuals() {
        List<ManualModel> manuals = new ArrayList<>();
        ResultSet resultSet = null;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT * FROM manual ORDER BY id_manual ASC";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                ManualModel manual = new ManualModel();
                manual.setManualId(resultSet.getInt("id_manual"));
                manual.setAdminFlag(resultSet.getInt("para_admin"));
                manual.setAdminFlagName(resultSet.getInt("para_admin"));
                manual.setManualName(resultSet.getString("nombre_manual"));
                manual.setManualLink(resultSet.getString("enlace_manual"));

                manuals.add(manual);
            }

            // Devolver la lista de tutoriales
            return manuals;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA "ACTUALIZAR" MANUAL
    private static int updateManual(int manual_id, String ManualName, String ManualLink) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR MANUAL
            String sql = "UPDATE manual SET nombre_manual=?, enlace_manual=? WHERE id_manual = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, ManualName);
            statement.setString(2, ManualLink);
            statement.setInt(3, manual_id);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }

    //METODO PARA "ELIMINAR" MANUAL
    private static int deleteManual(int manual_id) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR MANUAL
            String sql = "DELETE FROM manual WHERE id_manual=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, manual_id);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }

    }

}
