package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.AnswerModel;
import model.ConexionBD;
import model.QuestionModel;
import model.UserModel;

@WebServlet(name = "NextQuestionServlet", urlPatterns = "/NextQuestionServlet")
public class NextQuestionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        UserModel userInfo = (UserModel) session.getAttribute("userInfo");
        List<QuestionModel> questions = (List<QuestionModel>) session.getAttribute("pregAsignadas");
        List<AnswerModel> answers;

        int user_id = userInfo.getUserId();
        int index = Integer.parseInt(request.getParameter("index"));
        int questionary_id = userInfo.getQuestionaryId();
        int id_question = questions.get(index).getQuestionId();
        String answer = request.getParameter("option");

        // Redirigir a la siguiente pregunta o agradecimiento si es la última pregunta
        if (index < questions.size() - 1) {

            saveAnswer(user_id, questionary_id, id_question, answer);

            answers = getAnswers(user_id, questionary_id);

            request.getSession().setAttribute("respuestas", answers);
            response.sendRedirect(request.getContextPath() + "/Mi_cuestionario.jsp?index=" + (index + 1));

        } else {
            saveAnswer(user_id, questionary_id, id_question, answer);
            response.sendRedirect(request.getContextPath() + "/Cuestionario_finalizado.jsp");
        }

    }

    //ACTUALIZAR RESPUESTAS
    private static List<AnswerModel> getAnswers(int user_id, int questionary_id) {
        List<AnswerModel> answers = new ArrayList<>();
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS
            String sql = "SELECT * FROM cuestionario_respuesta WHERE id_usuario = ? AND id_cuestionario = ? ORDER BY id_pregunta ASC";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, user_id);
            statement.setInt(2, questionary_id);

            resultSet = statement.executeQuery();

            // Procesa los resultados 
            while (resultSet.next()) {
                AnswerModel answer = new AnswerModel();
                answer.setQuestionAnswerId(resultSet.getInt("id_cuestionario_respuesta"));
                answer.setUserId(resultSet.getInt("id_usuario"));
                answer.setQuestionaryId(resultSet.getInt("id_cuestionario"));
                answer.setQuestionId(resultSet.getInt("id_pregunta"));
                answer.setAnswer(resultSet.getString("respuesta"));

                answers.add(answer);
            }

            // Devolver la lista de RESPUESTAS
            return answers;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. updateAnswers");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA GUARDAR RESPUESTA
    private static int saveAnswer(int user_id, int questionary_id, int id_question, String answer) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR TUTORIAL
            String sql = "UPDATE cuestionario_respuesta SET respuesta = ? WHERE id_cuestionario = ? AND id_pregunta = ? AND id_usuario = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, answer);
            statement.setInt(2, questionary_id);
            statement.setInt(3, id_question);
            statement.setInt(4, user_id);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos. saveAnswer");
            e.printStackTrace();
            return 0;
        }

    }

    
}
