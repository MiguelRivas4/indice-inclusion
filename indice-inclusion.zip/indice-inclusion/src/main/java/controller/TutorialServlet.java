package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.*;

@WebServlet(name = "TutorialServlet", urlPatterns = "/TutorialServlet")
public class TutorialServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int admin_flag;

        //CREA UN OBJETO PARA OBTENER LA SESION ACTUAL
        HttpSession session = request.getSession(false);

        //SE OBTIENE EL ATRIBUTO "userInfo" EL CUAL CONTIENE LOS DATOS DE LA SESION DEL USUARIO ACTUAL 
        //Y LOS GUARDA EN EL OBJETO "userInfo" de tipo "UserModel" PARA PODER OBTENER SUS DATOS.
        UserModel userInfo = (UserModel) session.getAttribute("userInfo");
        List<TutorialModel> tutoriales;
        admin_flag = userInfo.getRoleId() != 6 ? 0 : 1;
        tutoriales = getTutorials(admin_flag);
        
        //Guarda la lista de manuales que devuelve la funcion getManuals
        List<ManualModel> manuales;
        manuales = getManuals();

        // Guarda la lista de tutoriales en la sesión para usarla en el JSP
        request.getSession().setAttribute("tutoriales", tutoriales);
        request.getSession().setAttribute("manuales", manuales);

        //SE REDIRECCIONA A LA PAGINA DE TUTORIALES Y MANUALES
        response.sendRedirect(request.getContextPath() + "/Tutoriales_y_manuales.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
    }

    //METODO PARA "LEER" TUTORIALES 
    private static List<TutorialModel> getTutorials(int tipoUsuario) {
        List<TutorialModel> tutoriales = new ArrayList<>();
        ResultSet resultSet = null;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            if (tipoUsuario == 0) {
                //QUERY PARA TUTORIALES PARA USUARIO COMUN 
                String sql = "SELECT * FROM tutorial WHERE para_admin=? ORDER BY id_tutorial ASC";
                PreparedStatement statement = conexion.prepareStatement(sql);
                statement.setInt(1, tipoUsuario);

                resultSet = statement.executeQuery();
            } else {
                //QUERY PARA TUTORIALES PARA USUARIO ADMIN
                String sql = "SELECT * FROM tutorial ORDER BY id_tutorial ASC";
                Statement statement = conexion.createStatement();
                resultSet = statement.executeQuery(sql);
            }

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                TutorialModel tutorial = new TutorialModel();
                tutorial.setTutorialId(resultSet.getInt("id_tutorial"));
                tutorial.setAdminFlag(resultSet.getInt("para_admin"));
                tutorial.setTutorialName(resultSet.getString("nombre_tutorial"));
                tutorial.setTutorialLink(resultSet.getString("enlace_tutorial"));

                tutoriales.add(tutorial);
            }

            // Devolver la lista de tutoriales
            return tutoriales;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA "LEER" MANUALES
    private static List<ManualModel> getManuals() {
        List<ManualModel> manuals = new ArrayList<>();
        ResultSet resultSet = null;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT * FROM manual ORDER BY id_manual ASC";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                ManualModel manual = new ManualModel();
                manual.setManualId(resultSet.getInt("id_manual"));
                manual.setManualName(resultSet.getString("nombre_manual"));
                manual.setManualLink(resultSet.getString("enlace_manual"));

                manuals.add(manual);
            }

            // Devolver la lista de tutoriales
            return manuals;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return null;
        }
    }

}
