package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.AnswerModel;
import model.ConexionBD;
import model.QuestionModel;
import model.UserModel;

@WebServlet(name = "MiCuestionarioServlet", urlPatterns = "/MiCuestionarioServlet")
public class MiCuestionarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        UserModel userInfo = (UserModel) session.getAttribute("userInfo");
        List<AnswerModel> answers;

        int user_id = userInfo.getUserId();
        int id_tipo = userInfo.getRoleId();
        int id_cuestionario = userInfo.getQuestionaryId();

        if (!isQuestionaryFinished(user_id, id_cuestionario)) {
            List<QuestionModel> questions = getAssignedQuestions(id_tipo, id_cuestionario);

            if (!validateUserID(user_id, id_cuestionario)) {
                questions.forEach(question -> {
                    InsertQuestionxAnswer(user_id, id_cuestionario, question.getQuestionId());
                });
            }

            answers = getAnswers(user_id, id_cuestionario);

            request.getSession().setAttribute("pregAsignadas", questions);
            request.getSession().setAttribute("respuestas", answers);
            response.sendRedirect(request.getContextPath() + "/Mi_cuestionario.jsp?index=0");
        }else{
            response.sendRedirect(request.getContextPath() + "/Cuestionario_finalizado.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    //METODO PARA REALIZAR GUARDADO DE PREGUNTAS POR CUESTIONARIO
    private static void InsertQuestionxAnswer(int user_id, int id_cuestionario, int id_pregunta) {
        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO cuestionario_respuesta (id_usuario, id_cuestionario, id_pregunta, respuesta) VALUES (?, ?, ?, ?)";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, user_id);
            statement.setInt(2, id_cuestionario);
            statement.setInt(3, id_pregunta);
            statement.setString(4, "");

            statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. InsertQuestionxQuestionary");
            e.printStackTrace();
        }
    }

    //METODO PARA OBTENER TODAS LAS PREGUNTAS ASIGNADAS AL USUARIO
    private static List<QuestionModel> getAssignedQuestions(int id_tipo, int id_cuestionario) {
        List<QuestionModel> questions = new ArrayList<>();
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS
            String sql = "SELECT p.id_pregunta, p.enunciado_pregunta, p.id_tipo "
                    + "FROM cuestionario_pregunta cp INNER JOIN pregunta p "
                    + "ON cp.id_pregunta = p.id_pregunta WHERE p.id_tipo = ? AND "
                    + "cp.id_cuestionario = ? "
                    + "ORDER BY p.id_pregunta ASC ";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, id_tipo);
            statement.setInt(2, id_cuestionario);

            resultSet = statement.executeQuery();

            // Procesa los resultados 
            while (resultSet.next()) {
                QuestionModel question = new QuestionModel();
                question.setQuestionId(resultSet.getInt("id_pregunta"));
                question.setQuestionDesc(resultSet.getString("enunciado_pregunta"));
                question.setCodeRol(resultSet.getInt("id_tipo"));

                questions.add(question);
            }

            // Devolver la lista de PREGUNTAS
            return questions;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. getAssignedQuestions");
            e.printStackTrace();
            return null;
        }
    }

    private static List<AnswerModel> getAnswers(int user_id, int questionary_id) {
        List<AnswerModel> answers = new ArrayList<>();
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS
            String sql = "SELECT * FROM cuestionario_respuesta WHERE id_usuario = ? AND id_cuestionario = ? ORDER BY id_pregunta ASC";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, user_id);
            statement.setInt(2, questionary_id);

            resultSet = statement.executeQuery();

            // Procesa los resultados 
            while (resultSet.next()) {
                AnswerModel answer = new AnswerModel();
                answer.setQuestionAnswerId(resultSet.getInt("id_cuestionario_respuesta"));
                answer.setUserId(resultSet.getInt("id_usuario"));
                answer.setQuestionaryId(resultSet.getInt("id_cuestionario"));
                answer.setQuestionId(resultSet.getInt("id_pregunta"));
                answer.setAnswer(resultSet.getString("respuesta"));

                answers.add(answer);
            }

            // Devolver la lista de RESPUESTAS
            return answers;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. getAnswers");
            e.printStackTrace();
            return null;
        }
    }

    private static boolean validateUserID(int user_id, int questionary_id) {
        ResultSet resultSet;
        int total = 0;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS
            String sql = "SELECT COUNT(*) FROM cuestionario_respuesta WHERE id_usuario = ? AND id_cuestionario = ?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, user_id);
            statement.setInt(2, questionary_id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                total = resultSet.getInt(1);
                return total > 0;
            }

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. validateUserID");
            e.printStackTrace();
        }

        return total > 0;
    }

    //METODO PARA SABER SI EL CUESTIONARIO ESTA FINALIZADO
    private static boolean isQuestionaryFinished(int user_id, int questionary_id) {
        ResultSet resultSet;
        int qMissing = 1;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS
            String sql = "SELECT COUNT(*) FROM cuestionario_respuesta WHERE id_usuario = ? AND id_cuestionario = ? AND (respuesta = '' or respuesta IS NULL)";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, user_id);
            statement.setInt(2, questionary_id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                qMissing = resultSet.getInt(1);
                
                return qMissing == 0;
            }

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. updateAnswers");
            e.printStackTrace();
        }

        return qMissing == 0;
    }
}
