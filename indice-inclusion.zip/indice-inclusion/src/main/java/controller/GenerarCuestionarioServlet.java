package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.ConexionBD;
import model.QuestionModel;
import model.UserModel;

@WebServlet(name = "GenerarCuestionarioServlet", urlPatterns = "/GenerarCuestionarioServlet")
public class GenerarCuestionarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Definicion de objeto sesion para obtener informacion del usuario actual
        HttpSession session = request.getSession(false);
        UserModel userInfo = (UserModel) session.getAttribute("userInfo");

        //Definiciones para obtener fecha de creacion del cuestionario
        LocalDateTime actualDate = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String creationDate = actualDate.format(formatter);

        //Definicion para fecha de vencimiento del cuestionario
        String end_date = request.getParameter("fecha_vencimiento");
        int school_id = userInfo.getSchoolId();
        
        //Se deberia llamar primero a CreateParameter para crear los parametros que utilizara el cuestionario
        boolean parameterCreated = CreateParameter("TEST", "TEST", "TEST", school_id);

        if (parameterCreated) {
            int id_parameter = getLastParameter();

            if (id_parameter != 0) {
                if (CreateQuestionary("test", "test", "test", end_date, 1, id_parameter, creationDate)) {
                    int lastQuestionary = getLastQuestionary();
                    if (lastQuestionary != 0) {
                        List<QuestionModel> questions = getQuestionsToQuestionary();

                        questions.forEach(question -> {
                            InsertQuestionxQuestionary(lastQuestionary, question.getQuestionId());
                        });
                        
                        assignQuestionaryToUsers(lastQuestionary, school_id);
                        response.sendRedirect(request.getContextPath() + "/Generar_cuestionario.jsp");
                    } else {
                        System.out.println("Ocurrio un error al obtener ultimo cuestionario");
                    }
                }
            } else {
                System.out.println("Ocurrio un error al obtener ultimo parametro");
            }
        } else {
            System.out.println("Ocurrio un error al crear el parametro");
        }

    }

    //METODO PARA OBTENER ULTIMO PARAMETRO CREADO
    private static int getLastParameter() {
        int lastParameter;
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT id_parametro FROM parametros_cuestionario ORDER BY id_parametro DESC FETCH FIRST 1 ROW ONLY";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea guarda el id del ultimo conjunto de parametros creado
            if (resultSet.next()) {
                lastParameter = resultSet.getInt("id_parametro");
            } else {
                lastParameter = 0;
            }

            // Devolver la lista de tutoriales
            return lastParameter;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. getLastParameter");
            e.printStackTrace();
            return 0;
        }
    }

    //METODO PARA "CREAR" PARAMETRO
    private static boolean CreateParameter(String composition, String disabilities, String ambits, int school_id) {

        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO parametros_cuestionario (composicion_docentes, discapacidades, ambito_pregunta, id_centro) VALUES (?, ?, ?, ?);";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, composition);
            statement.setString(2, disabilities);
            statement.setString(3, ambits);
            statement.setInt(4, school_id);

            statement.executeUpdate();

            // Devolver true si se ejecuto correctamente
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. CreateParameter");
            e.printStackTrace();
            return false;
        }
    }

    //METODO PARA "CREAR" CUESTIONARIO
    private static boolean CreateQuestionary(String title, String description, String start_date, String end_date, int id_state, int id_parameter, String created_at) {

        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO cuestionario (titulo, descripcion, fecha_inicio, fecha_fin, id_estado, id_parametro, fecha_creacion) VALUES (?, ?, ?, ?, ?, ?, ?);";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, title);
            statement.setString(2, description);
            statement.setString(3, start_date);
            statement.setString(4, end_date);
            statement.setInt(5, id_state);
            statement.setInt(6, id_parameter);
            statement.setString(7, created_at);

            statement.executeUpdate();

            // Devolver true si se ejecuto correctamente
            return true;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. CreateQuestionary");
            e.printStackTrace();
            return false;
        }
    }

    //METODO PARA OBTENER ULTIMO CUESTIONARIO CREADO
    private static int getLastQuestionary() {
        int lastQuestionary;
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODOS LOS TUTORIALES
            String sql = "SELECT id_cuestionario FROM cuestionario ORDER BY id_cuestionario DESC FETCH FIRST 1 ROW ONLY";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea guarda el id del ultimo conjunto de parametros creado
            if (resultSet.next()) {
                lastQuestionary = resultSet.getInt("id_cuestionario");
            } else {
                lastQuestionary = 0;
            }

            // Devolver la lista de tutoriales
            return lastQuestionary;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. getLastQuestionary");
            e.printStackTrace();
            return 0;
        }
    }

    //METODO PARA OBTENER TODAS LAS PREGUNTAS A ASIGNAR EN EL CUESTIONARIO
    private static List<QuestionModel> getQuestionsToQuestionary() {
        List<QuestionModel> questions = new ArrayList<>();
        ResultSet resultSet;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA OBTENER TODAS LAS PREGUNTAS A ASIGNAR EN EL CUESTIONARIO
            //TODO: aqui se debe usar un query que tenga todos los parametros
            String sql = "SELECT id_pregunta FROM pregunta";
            Statement statement = conexion.createStatement();
            resultSet = statement.executeQuery(sql);

            // Procesa los resultados y crea objetos Tutorial
            while (resultSet.next()) {
                QuestionModel questionID = new QuestionModel();
                questionID.setQuestionId(resultSet.getInt("id_pregunta"));

                questions.add(questionID);
            }

            // Devolver la lista de PREGUNTAS
            return questions;

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. getQuestionsToQuestionary");
            e.printStackTrace();
            return null;
        }
    }

    //METODO PARA REALIZAR GUARDADO DE PREGUNTAS POR CUESTIONARIO
    private static void InsertQuestionxQuestionary(int id_cuestionario, int id_pregunta) {
        try (Connection conexion = ConexionBD.obtenerConexion()) {
            String sql = "INSERT INTO cuestionario_pregunta(id_cuestionario, id_pregunta) VALUES (?, ?)";

            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, id_cuestionario);
            statement.setInt(2, id_pregunta);

            statement.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error en la base de datos. InsertQuestionxQuestionary");
            e.printStackTrace();
        }
    }

    private static int assignQuestionaryToUsers(int id_cuestionario, int id_centro) {
        int filasAfectadas;

        try (Connection conexion = ConexionBD.obtenerConexion()) {

            //QUERY PARA ELIMINAR TUTORIAL
            String sql = "UPDATE usuario SET id_cuestionario = ? WHERE id_centro = ? ";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setInt(1, id_cuestionario);
            statement.setInt(2, id_centro);

            filasAfectadas = statement.executeUpdate();

            // Devolver cantidad de filas afectadas
            return filasAfectadas;
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            e.printStackTrace();
            return 0;
        }
    }
    

}
