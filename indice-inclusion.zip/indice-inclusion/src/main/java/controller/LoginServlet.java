package controller;

import model.ConexionBD;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.UserModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = "/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        //Se obtiene los valores de los campos de usuario y contraseña
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try {
            //Se crea nuevo objeto usuario y valida sus credenciales
            UserModel user = validateCredentials(username, password);
            
            //System.out.println("ID USUARIO: " + user.getUserId());
            //System.out.println("Nombre USUARIO: " + user.getUsername());
            //System.out.println("Direccion USUARIO: " + user.getAddress());
            //System.out.println("ID CENTRO ESCOLAR: " + user.getSchoolId());
            //System.out.println("ID ROL DE USUARIO: " + user.getRoleId());
            //System.out.println("ID DEPARTAMENTO: " + user.getDepartmentId());
            
            //VALIDA CREDENCIALES DEL USUARIO
            if (user != null) {
                //SE GUARDA EL NOMBRE DEL USUARIO EN EL OBJETO SESSION PARA PODER ACCEDERLO DESDE CUALQUIER PAGINA
                HttpSession session = request.getSession();
                session.setAttribute("userInfo", user);
                
                //SE REDIRECCIONA A LA PAGINA DE 
                response.sendRedirect(request.getContextPath() + "/Introduccion.jsp");
            } else {
                // Credenciales incorrectas, redirigir a Login.jsp con el parámetro de error
                response.sendRedirect(request.getContextPath() + "/Login.jsp?error=true");
            }
        }
        finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
 
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public static UserModel validateCredentials(String username, String password) {
        try (Connection conexion = ConexionBD.obtenerConexion()) {

            String sql = "SELECT * FROM usuario WHERE nombre_usuario=? AND contrasenia=?";
            PreparedStatement statement = conexion.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            
            if (!resultSet.next()) {
                //System.out.println(" No se encontro el usuario");
                return null;
            } else {
                //System.out.println("Se encontró el usuario");
                
                UserModel usr = new UserModel();
                
                usr.setUserId(resultSet.getInt("id_usuario"));
                usr.setUsername(resultSet.getString("nombre_usuario"));
                usr.setAddress(resultSet.getString("direccion"));
                usr.setSchoolId(resultSet.getInt("id_centro"));
                usr.setRoleId(resultSet.getInt("id_rol"));
                usr.setDepartmentId(resultSet.getInt("id_departamento"));
                usr.setRoleName(resultSet.getInt("id_rol"));
                usr.setQuestionaryId(resultSet.getInt("id_cuestionario"));
                
                // Devolver el usuario con sus datos si las credenciales son válidas
                return usr;
            }
        } catch (SQLException e) {
            System.out.println("Error en la base de datos.");
            return null;
        }
    }
    
    
    
}
