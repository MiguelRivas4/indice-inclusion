package model;

public class QuestionModel {

    private int Question_id;
    private String Dimension;
    private String Ambit;
    private String Question_description;
    private int Cod_rol;
    private String Cod_rol_name;

    public int getQuestionId() {
        return Question_id;
    }

    public void setQuestionId(int question_id) {
        this.Question_id = question_id;
    }

    public String getDimension() {
        return Dimension;
    }

    public void setDimension(String dimension) {
        this.Dimension = dimension;
    }

    public String getAmbit() {
        return Ambit;
    }

    public void setAmbit(String ambit) {
        this.Ambit = ambit;
    }

    public String getQuestionDesc() {
        return Question_description;
    }

    public void setQuestionDesc(String question_description) {
        this.Question_description = question_description;
    }

    public int getCodeRol() {
        return Cod_rol;
    }

    public void setCodeRol(int cod_rol) {
        this.Cod_rol = cod_rol;
    }

    public String getCodRoleName() {
        return Cod_rol_name;
    }

    public void setCodRoleName(int cod_rol_name) {

        switch (cod_rol_name) {
            case 1:
                this.Cod_rol_name = "Director";
                break;
            case 2:
                this.Cod_rol_name = "Docentes";
                break;
            case 3:
                this.Cod_rol_name = "Familiares";
                break;
            case 4:
                this.Cod_rol_name = "Comunidad";
                break;
            case 5:
                this.Cod_rol_name = "Parvularia";
                break;
            case 6:
                this.Cod_rol_name = "Primer Ciclo";
                break;
            case 7:
                this.Cod_rol_name = "Segundo Ciclo";
                break;
            case 8:
                this.Cod_rol_name = "Tercer Ciclo y Media";
                break;
            default:
                //ERROR EN CODIGO DE ROL PARA PREGUNTA
                this.Cod_rol_name = "";
        }
    }
}
