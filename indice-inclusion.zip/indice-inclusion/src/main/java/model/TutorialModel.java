package model;

public class TutorialModel {
    private int tutorial_id;
    private int admin_flag;
    private String admin_flag_name;
    private String tutorial_name;
    private String tutorial_link;
    
    public int getTutorialId() {
        return tutorial_id;
    }

    public void setTutorialId(int tutorial_id) {
        this.tutorial_id = tutorial_id;
    }

    public int getAdminFlag() {
        return admin_flag;
    }

    public void setAdminFlag(int admin_flag) {
        this.admin_flag = admin_flag;
    }
    
    public String getAdminFlagName() {
        return admin_flag_name;
    }

    public void setAdminFlagName(int admin_flag) {
        if(admin_flag == 0){
            this.admin_flag_name = "Usuarios";
        }else{
            this.admin_flag_name = "Administradores";
        }
    }

    public String getTutorialName() {
        return tutorial_name;
    }

    public void setTutorialName(String tutorial_name) {
        this.tutorial_name = tutorial_name;
    }

    public String getTutorialLink() {
        return tutorial_link;
    }

    public void setTutorialLink(String tutorial_link) {
        this.tutorial_link = tutorial_link;
    }

    
}
