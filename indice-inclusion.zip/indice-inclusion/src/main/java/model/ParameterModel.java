package model;

import java.sql.Date;

public class ParameterModel {
    private int Parameter_id;
    private String Composition;
    private String Disabilities;
    private String Ambits;
    private int School_id;

    public int getParameterId() {
        return Parameter_id;
    }

    public void setParameterId(int parameter_id) {
        this.Parameter_id = parameter_id;
    }

    public String getComposition() {
        return Composition;
    }

    public void setComposition(String composition) {
        this.Composition = composition;
    }

    public String getDisabilities() {
        return Disabilities;
    }

    public void setDisabilities(String disabilities) {
        this.Disabilities = disabilities;
    }

    public String getAmbits() {
        return Ambits;
    }

    public void setAmbits(String ambits) {
        this.Ambits = ambits;
    }

    public int getSchoolId() {
        return School_id;
    }

    public void setSchoolId(int school_id) {
        this.School_id = school_id;
    }
    
}
