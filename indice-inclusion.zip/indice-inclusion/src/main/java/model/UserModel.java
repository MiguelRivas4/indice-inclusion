package model;

public class UserModel {

    private int user_id;
    private String username;
    private String password;
    private String address;
    private int school_id;
    private int role_id;
    private String role_name;
    private int department_id;
    private int questionary_id;

    public int getUserId() {
        return user_id;
    }

    public void setUserId(int user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSchoolId() {
        return school_id;
    }

    public void setSchoolId(int school_id) {
        this.school_id = school_id;
    }

    public int getRoleId() {
        return role_id;
    }

    public void setRoleId(int role_id) {
        this.role_id = role_id;
    }

    public int getDepartmentId() {
        return department_id;
    }

    public void setDepartmentId(int department_id) {
        this.department_id = department_id;
    }

    public String getRoleName() {
        return role_name;
    }

    public void setRoleName(int Role_name) {

        switch (Role_name) {
            case 1:
                this.role_name = "Directores";
                break;
            case 2:
                this.role_name = "Docentes";
                break;
            case 3:
                this.role_name = "Familiares";
                break;
            case 4:
                this.role_name = "Comunidad";
                break;
            case 5:
                this.role_name = "Parvularia";
                break;
            case 6:
                this.role_name = "Primer Ciclo";
                break;
            case 7:
                this.role_name = "Segundo Ciclo";
                break;
            case 8:
                this.role_name = "Tercer Ciclo y Media";
                break;
            case 9:
                this.role_name = "DEI,DDE";
                break;
            case 10:
                this.role_name = "Admin";
                break;
            default:
                //ERROR EN CODIGO DE ROL PARA PREGUNTA
                this.role_name = "";
        }
    }

    public int getQuestionaryId() {
        return questionary_id;
    }

    public void setQuestionaryId(int Questionary_id) {
        this.questionary_id = Questionary_id;
    }
}
