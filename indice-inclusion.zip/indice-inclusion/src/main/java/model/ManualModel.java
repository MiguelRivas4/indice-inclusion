package model;

public class ManualModel {

    private int manual_id;
    private int admin_flag;
    private String admin_flag_name;
    private String manual_name;
    private String manual_link;

    public int getManualId() {
        return manual_id;
    }

    public void setManualId(int manual_id) {
        this.manual_id = manual_id;
    }
    
    public int getAdminFlag() {
        return admin_flag;
    }

    public void setAdminFlag(int admin_flag) {
        this.admin_flag = admin_flag;
    }
    
    public String getAdminFlagName() {
        return admin_flag_name;
    }

    public void setAdminFlagName(int admin_flag) {
        if(admin_flag == 0){
            this.admin_flag_name = "Usuarios";
        }else{
            this.admin_flag_name = "Administradores";
        }
    }
    
    public String getManualName() {
        return manual_name;
    }

    public void setManualName(String manual_name) {
        this.manual_name = manual_name;
    }

    public String getManualLink() {
        return manual_link;
    }

    public void setManualLink(String manual_link) {
        this.manual_link = manual_link;
    }
}
