package model;

public class QuestionaryModel {

    private int Questionary_id;
    private String Title;
    private String Description;
    private String Start_date;
    private String End_date;
    private int Id_state;
    private int Id_parameter;
    private String Type_name;
    private String State_name;
    private String Created_at;

    public int getQuestionaryId() {
        return Questionary_id;
    }

    public void setQuestionId(int questionary_id) {
        this.Questionary_id = questionary_id;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        this.Title = title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        this.Description = description;
    }

    public String getStart_date() {
        return Start_date;
    }

    public void setStart_date(String start_date) {
        this.Start_date = start_date;
    }

    public String getEnd_date() {
        return End_date;
    }

    public void setEnd_date(String end_date) {
        this.End_date = end_date;
    }

    public int getState() {
        return Id_state;
    }

    public void setState(int id_estado) {
        this.Id_state = id_estado;
    }
    
    public String getStateName() {
        return State_name;
    }

    public void setStateName(int id_estado) {

        switch (id_estado) {
            case 1:
                this.State_name = "Creado";
                break;
            case 2:
                this.State_name = "Activo";
                break;
            case 3:
                this.State_name = "Finalizado";
                break;
            case 4:
                this.State_name = "Inactivo";
                break;
            default:
                //ERROR EN CODIGO DE ROL PARA PREGUNTA
                this.State_name = "";
        }
    }

    public int getParameter() {
        return Id_parameter;
    }

    public void setParameter(int id_parametro) {
        this.Id_parameter = id_parametro;
    }
    
    public String getCreationDate() {
        return Created_at;
    }

    public void setCreationDate(String created_at) {
        this.Created_at = created_at;
    }

}
