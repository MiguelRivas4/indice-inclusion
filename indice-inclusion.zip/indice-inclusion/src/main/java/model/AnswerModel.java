package model;

public class AnswerModel {

    private int QuestionAnswer_Id;
    private int User_id ;
    private int Questionary_id;
    private int Question_id;
    private String Answer;
    
    public int getQuestionAnswerId() {
        return QuestionAnswer_Id;
    }

    public void setQuestionAnswerId(int questionAnswer_Id) {
        this.QuestionAnswer_Id = questionAnswer_Id;
    }
    
    public int getUserId() {
        return User_id;
    }

    public void setUserId(int user_id) {
        this.User_id = user_id;
    }
    
    public int getQuestionaryId() {
        return Questionary_id;
    }

    public void setQuestionaryId(int questionary_id) {
        this.Questionary_id = questionary_id;
    }
    
    public int getQuestionId() {
        return Question_id;
    }

    public void setQuestionId(int question_id) {
        this.Question_id = question_id;
    }

    public String getAnswer() {
        return Answer;
    }

    public void setAnswer(String answer) {
        this.Answer = answer;
    }

}
