function mostrarDetalleAdmin() {
    var card1 = document.getElementById("idCard1").textContent;
    var card2 = document.getElementById("idCard2").textContent;
    var card3 = document.getElementById("idCard3").textContent;
    var card4 = document.getElementById("idCard4").textContent;
    // Lógica para mostrar detalles del manual de administración
    alert("Detalles de card 1: " + card1);
    alert("Detalles de card 2: " + card2);
    alert("Detalles de card 3: " + card3);
    alert("Detalles de card 4: " + card4);
}
