/*JS PARA HABILITAR MENU DE ACORDEON */
//SCRIPT PARA MOSTRAR Y OCULTAR MENU DE ACORDEON
function toggleAccordionMenu(iconId) {
    var arrowIcon = document.getElementById(iconId);
    var accordionContent = arrowIcon.parentElement.nextElementSibling;

    // Verificar la clase actual del icono
    if (arrowIcon.classList.contains("fa-caret-right")) {
        // Si tiene la clase 'fa-caret-right', cambiar a 'fa-caret-down'
        arrowIcon.classList.remove("fa-caret-right");
        arrowIcon.classList.add("fa-caret-down");

        // Mostrar las opciones del menú de acordeón
        accordionContent.style.display = "block";
    } else {
        // Si tiene la clase 'fa-caret-down', cambiar a 'fa-caret-right'
        arrowIcon.classList.remove("fa-caret-down");
        arrowIcon.classList.add("fa-caret-right");

        // Ocultar las opciones del menú de acordeón
        accordionContent.style.display = "none";
    }
}

