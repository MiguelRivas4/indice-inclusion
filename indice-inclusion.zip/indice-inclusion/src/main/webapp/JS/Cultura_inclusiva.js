function toggleAddPopup() {
    var popup = document.getElementById('AddPopup');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleDeletePopup() {
    var popup = document.getElementById('delPopup');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleEditPopup() {
    var popup = document.getElementById('editPopup');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function getRowDetail(accion) {
    event.preventDefault();

    // Obtiene la fila actual (parentNode es la celda, y parentNode de nuevo es la fila)
    var row = event.target.parentNode.parentNode;

    // Obtiene los valores de las celdas de la fila
    var ID = row.cells[0].textContent;
    var DIMENSION = row.cells[1].textContent;
    var AMBIT = row.cells[2].textContent;
    var QUESTION = row.cells[3].textContent;
    var TIPO = row.cells[4].textContent;

    switch (accion) {
        case "edit":
            //Variables a sustituir valor
            var id_questionN = document.getElementById('id_questionE');
            var dimensionN = document.getElementById('dimensionE');
            var ambitN = document.getElementById('ambitoE');
            var questionDescN = document.getElementById('enunciadoE');
            var cod_rolN = document.getElementById('id_tipoE');

            id_questionN.value = ID;
            dimensionN.value = DIMENSION;
            ambitN.value = AMBIT;
            questionDescN.value = QUESTION;
            cod_rolN.value = TIPO;

            for (var i = 0; i < ambitN.options.length; i++) {
                if (ambitN.options[i].text === AMBIT) {
                    ambitN.options[i].selected = true;
                    break;
                }
            }
            
            for (var i = 0; i < cod_rolN.options.length; i++) {
                if (cod_rolN.options[i].text === TIPO) {
                    cod_rolN.options[i].selected = true;
                    break;
                }
            }

            toggleEditPopup();
            break;

        case "del":
            var questionD = document.getElementById('question');
            var id_preguntaD = document.getElementById('id_questionD');

            questionD.textContent = QUESTION;
            id_preguntaD.value = ID;


            toggleDeletePopup();
            break;
        default:
        //console.log("Opción no reconocida");
    }
}

