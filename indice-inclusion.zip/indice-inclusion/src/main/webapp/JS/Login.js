function showErrorMessage() {
    setTimeout(function () {
        alert("Credenciales incorrectas. Por favor, inténtelo de nuevo.");
        document.getElementById("usuario").value = "";  // Limpiar el campo de usuario
        document.getElementById("clave").value = "";    // Limpiar el campo de contraseña
    }, 700);
}
