function togglePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function next() {
    // Lógica para avanzar la pregunta
    var answerForm = document.getElementById("answersForm");
    
    answerForm.submit();
}

function back() {
    // Lógica para avanzar la pregunta
    var answerFormBack = document.getElementById("answersFormBack");
    
    answerFormBack.submit();
}

