function toggleEditPopupM() {
    var popup = document.getElementById('editPopupM');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleDeletePopupM() {
    var popup = document.getElementById('delPopupM');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleAddPopupT() {
    var popup = document.getElementById('AddPopupT');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleEditPopupT() {
    var popup = document.getElementById('editPopupT');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function toggleDeletePopupT() {
    var popup = document.getElementById('delPopupT');
    popup.style.display = (popup.style.display === 'none' || popup.style.display === '') ? 'block' : 'none';
}

function getRowDetailT(accion) {
    event.preventDefault();

    // Obtiene la fila actual (parentNode es la celda, y parentNode de nuevo es la fila)
    var row = event.target.parentNode.parentNode;

    // Obtiene los valores de las celdas de la fila
    var ID = row.cells[0].textContent;
    var TUTORIAL = row.cells[1].textContent;
    var LINK = row.cells[2].textContent;
    var toAdmin = row.cells[3].textContent;

    switch (accion) {
        case "editT":
            //Variables a sustituir valor
            var id_tutorial = document.getElementById('id_tutorial');
            var toAdminFlag = document.getElementById('nuevoPara');
            var tutorial_name = document.getElementById('nuevoNombre');
            var tutorial_link = document.getElementById('nuevoEnlace');

            // Muestra los valores 
            //console.log('ID:', ID);
            //console.log('ADMIN FLAG:', toAdmin);
            //console.log('NAME:', TUTORIAL);
            //console.log('LINK:', LINK);

            id_tutorial.value = ID;
            tutorial_name.value = TUTORIAL;
            tutorial_link.value = LINK;

            for (var i = 0; i < toAdminFlag.options.length; i++) {
                if (toAdminFlag.options[i].text === toAdmin) {
                    toAdminFlag.options[i].selected = true;
                    break;
                }
            }

            toggleEditPopupT();
            break;

        case "delT":
            var tName = document.getElementById('tName');
            var id_tutorial = document.getElementById('id_tutorialD');
            // Muestra los valores
            //console.log('ID:', ID);
            //console.log('TUTORIAL:', TUTORIAL);

            tName.textContent = TUTORIAL;
            id_tutorial.value = ID;

            //console.log('HIDDEN ID AFTER:', id_tutorial.value);

            toggleDeletePopupT();
            break;
        default:
        //console.log("Opción no reconocida");
    }
}

function getRowDetailM(accion) {
    event.preventDefault();

    // Obtiene la fila actual (parentNode es la celda, y parentNode de nuevo es la fila)
    var row = event.target.parentNode.parentNode;

    // Obtiene los valores de las celdas de la fila
    var ID = row.cells[0].textContent;
    var MANUAL = row.cells[1].textContent;
    var LINK = row.cells[2].textContent;

    switch (accion) {
        case "editM":
            //Variables a sustituir valor
            var id_manual = document.getElementById('id_manual');
            var manual_name = document.getElementById('nuevoNombreM');
            var manual_link = document.getElementById('nuevoEnlaceM');

            // Muestra los valores 
            //console.log('ID:', ID);
            //console.log('MANUAL:', MANUAL);
            //console.log('LINK:', LINK);

            id_manual.value = ID;
            manual_name.value = MANUAL;
            manual_link.value = LINK;

            toggleEditPopupM();
            break;
        case "delM":
            var mName = document.getElementById('mName');
            var id_manual = document.getElementById('id_manualD');
            // Muestra los valores
            //console.log('ID:', ID);
            //console.log('MANUAL:', MANUAL);

            id_manual.value = ID;
            mName.textContent = MANUAL;

            
            toggleDeletePopupM();
            break;
        default:
        //console.log("Opción no reconocida");
    }
}

